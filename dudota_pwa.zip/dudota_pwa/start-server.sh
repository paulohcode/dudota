#!/bin/bash
# Servidor HTTP para Dudota Doces PWA
# Execute este script no Mac e acesse pelo tablet Android

cd "$(dirname "$0")"

echo "=========================================="
echo "   🍬 Dudota Doces — Servidor Local"
echo "=========================================="
echo ""

# Descobre o IP local
IP=$(ifconfig | grep "inet " | grep -v 127.0.0.1 | awk '{print $2}' | head -1)

echo "📡 Servidor iniciado!"
echo ""
echo "🔗 No tablet Android, abra o Chrome e digite:"
echo "   http://$IP:8080"
echo ""
echo "⚠️  Certifique-se de que o Mac e o tablet"
echo "   estão na MESMA rede WiFi!"
echo ""
echo "🛑 Pressione Ctrl+C para parar o servidor"
echo "=========================================="

python3 -m http.server 8080