const CACHE_NAME = 'dudota-doces-v1';
const urlsToCache = [
  './',
  './index.html',
  './carrinho.html',
  './cart.js',
  './manifest.json',
  './assets/logo.jpeg',
  './assets/bananitas.jpeg',
  './assets/canudo_8.jpeg',
  './assets/canudo_bandeja.jpeg',
  './assets/choco_mole_branco.jpeg',
  './assets/choco_mole.jpeg',
  './assets/doce_leite.jpeg',
  './assets/fondant_chocolate.jpeg',
  './assets/fondant_leite_po.jpeg',
  './assets/geleia_frutas.jpeg',
  './assets/maria_bonita.jpeg',
  './assets/pacoca_caseira.jpeg',
  './assets/pacoca_rolha_choc.jpeg',
  './assets/pacoca_rolha_trad.jpeg',
  './assets/pe_moleque_crocante.jpeg',
  './assets/pe_moleque.jpeg'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(urlsToCache))
  );
  self.skipWaiting();
});

self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        if (response) return response;
        return fetch(event.request);
      })
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames
          .filter(name => name !== CACHE_NAME)
          .map(name => caches.delete(name))
      );
    })
  );
  self.clients.claim();
});