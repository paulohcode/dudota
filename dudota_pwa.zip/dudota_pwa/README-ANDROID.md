# 📱 Dudota Doces — Como abrir no Android

## ⚠️ IMPORTANTE: Não abra o index.html diretamente!

Abrir o arquivo diretamente no navegador (file://) **não carrega as imagens** por questões de segurança do Android.

## ✅ Método correto: Servidor HTTP local

### Passo 1 — Inicie o servidor no Mac

Abra o Terminal na pasta `dudota_pwa/` e execute:

```bash
cd /Users/crtech/Desktop/dudota_site_com_fotos_backup_20260428_165245/dudota_pwa
python3 -m http.server 8080
```

Você verá:
```
Serving HTTP on :: port 8080 (http://[::]:8080/) ...
```

**Deixe o Terminal aberto!** O servidor precisa ficar rodando.

### Passo 2 — Descubra o IP do Mac

No mesmo Terminal, execute:

```bash
ifconfig | grep "inet " | grep -v 127.0.0.1
```

Você verá algo como:
```
inet 192.168.1.45 netmask ...
```

Anote o número: **`192.168.1.45`** (o seu será diferente)

### Passo 3 — Acesse pelo tablet Android

1. Certifique-se de que o **Mac e o tablet estão na mesma rede WiFi**
2. No tablet, abra o **Chrome**
3. Digite na barra de endereços:
   ```
   http://192.168.1.45:8080
   ```
   *(substitua pelo IP do seu Mac)*
4. As imagens devem aparecer normalmente!

### Passo 4 — Instalar como app (PWA)

No Chrome do tablet:
1. Toque no menu (⋮) no canto superior direito
2. Selecione **"Adicionar à tela inicial"** ou **"Instalar app"**
3. O ícone da Dudota Doces aparecerá na tela inicial do tablet
4. Ao abrir, o app funciona em tela cheia, sem barra de endereço

---

## 🔧 Alternativa: Se não tiver WiFi

Copie a pasta `dudota_pwa/` para o tablet via USB ou Google Drive, depois use um app como **"Web Server for Chrome"** ou **"KSWEB"** no próprio tablet para servir os arquivos localmente.

---

## 📂 Estrutura de arquivos

```
dudota_pwa/
├── index.html          ← Página principal
├── carrinho.html       ← Carrinho de compras
├── cart.js             ← Lógica do carrinho
├── manifest.json       ← Configuração PWA
├── sw.js               ← Cache offline
├── README-ANDROID.md   ← Este arquivo
└── assets/
    ├── logo.jpeg
    ├── icon-72.png ... icon-512.png
    └── [fotos dos produtos]